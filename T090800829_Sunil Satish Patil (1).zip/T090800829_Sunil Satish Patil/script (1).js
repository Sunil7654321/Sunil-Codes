let scores = [0, 0, 0];
let currentPlayer = 0;

document.getElementById('rollDice').addEventListener('click', function() {
    let roll = Math.floor(Math.random() * 6) + 1;
    document.getElementById('currentRoll').innerText = roll;

    if (roll !== 1) {
        scores[currentPlayer] += roll;
        document.getElementById(`score${currentPlayer + 1}`).innerText = scores[currentPlayer];
    }

    currentPlayer = (currentPlayer + 1) % 3;
    document.getElementById('currentPlayer').innerText = currentPlayer + 1;
});
